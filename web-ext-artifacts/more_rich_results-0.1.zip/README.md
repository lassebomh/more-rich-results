# More Rich Results

This extension adds more types of rich results to Google. It currently supports Reddit and the Stack Exchange network (Stack Overflow, Super User, Server Fault, etc.)

### Stack Exchange results

![Stack Exchange results](https://i.imgur.com/u8hI0wf.png)

### Reddit results

![Reddit results](https://i.imgur.com/MZjvbK4.png)

Support might later be added for other search engines.
